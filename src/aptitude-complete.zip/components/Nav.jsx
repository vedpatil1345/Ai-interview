import { SignedIn, SignedOut, SignInButton, UserButton } from "@clerk/nextjs";
import { Button } from "./ui/button";
const Nav = () => {
    return (
        <nav className="sticky z-50 top-0 left-0 right-0 h-6 flex flex-col">
            <div></div>
            <div></div>
            <div>
            <SignedOut>
            <SignInButton forceRedirectUrl="/sign-in">
              <Button variant="outline">Login/Signup</Button>
            </SignInButton>
          </SignedOut>
          <SignedIn>
            <UserButton
              appearance={{
                elements: {
                  avatarBox: "w-10 h-10",
                },
              }}
            />
          </SignedIn>
            </div>
        </nav>
    );
}

export default Nav;