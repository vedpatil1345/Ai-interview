import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import { HumanMessage } from "@langchain/core/messages";
import { NextResponse } from 'next/server';

const llm = ChatGoogleGenerativeAI(
    model:'',
)