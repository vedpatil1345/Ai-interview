import { clerkMiddleware } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";

// Define protected routes
const isProtectedRoute = (req) => {
  const url = req.nextUrl.pathname;
  return url.startsWith('/dashboard') || url.startsWith('/forum');
};

// Create your middleware function
const clerk = clerkMiddleware(async (auth, req) => {
  const { userId } = await auth();

  if (!userId && isProtectedRoute(req)) {
    // Direct implementation - no need to await auth() again
    return auth().redirectToSignIn({ returnBackUrl: req.url });
  }

  return NextResponse.next();
});

// Export the clerk middleware directly if not chaining with other middleware
export default clerk;

export const config = {
  matcher: [
    // Skip Next.js internals and all static files
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)",
    // Always run for API routes
    "/(api|trpc)(.*)",
  ],
};