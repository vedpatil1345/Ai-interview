export default function Page() {
    const agents=[
        {name:'Aryan',behaviour:'calm,polite,professional',color:'red'},
        {name:'Rohan',behaviour:'confident,not so polite,arogant',color: 'orange'},
        {name:'Aesha',behaviour:'friendly, polite, shy',color:'blue'},
        {name:'Vishwaa',behaviour:'confident,polite,professional',color:'pink'}
    ];
    
    return (
        <div>
            
        </div>
    );
}