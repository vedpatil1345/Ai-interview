import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import { HumanMessage } from "@langchain/core/messages";
import { NextResponse } from 'next/server';

// Predefined agents with their personalities
const agents = [
  {name: 'Aryan', behaviour: 'calm, polite, professional', color: 'red'},
  {name: 'Rohan', behaviour: 'confident, not so polite, arrogant', color: 'orange'},
  {name: 'Aesha', behaviour: 'friendly, polite, shy', color: 'blue'},
  {name: 'Vishwaa', behaviour: 'confident, polite, professional', color: 'pink'},
  {name:'You', behaviour: '', color: 'Green'}
];

export async function POST(req) {
  try {
    // Initialize the Gemini model
    const llm = new ChatGoogleGenerativeAI({
      apiKey: process.env.GEMINI_API_KEY,
      model: "gemini-2-flash",
      temperature: 0.3, // Slightly increased for more varied responses
      maxRetries: 2,
    });

    // Parse the request body
    const { currentMsg, chatHistory } = await req.json();
    
    // Get a random GD topic if not provided in the request
    let topic = currentMsg?.topic;
    if (!topic) {
      topic = await llm.predict('Suggest a challenging professional group discussion topic for a job interview. Give only the topic name in your response.');
    }
    
    // Select a random agent
    const currentAgent = agents[Math.floor(Math.random() * agents.length)];
    
    // Generate a comment from the selected agent based on their personality
    const prompt = `
      You are ${currentAgent.name}, a participant in a group discussion during a job interview.
      Your personality traits are: ${currentAgent.behaviour}.
      
      The discussion topic is: "${topic}"
      
      Previous discussion (if any):
      ${chatHistory ? chatHistory.map(msg => `${msg.speaker}: ${msg.text}`).join('\n') : 'Discussion is just beginning.'}
      
      Provide a single response (2-3 sentences) as ${currentAgent.name}, speaking in character according to your personality traits.
      Don't introduce yourself or mention your personality traits explicitly.
    `;
    
    // Get the agent's response
    const agentResponse = await llm.predict(prompt);
    
    // Return the response
    return NextResponse.json({
      topic: topic,
      currentAgent: currentAgent,
      response: agentResponse.trim()
    });
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    );
  }
}